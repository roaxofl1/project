const movies = [
  { title: "오펜하이머", genre: "드라마 · 스릴러", year: "2023", img: "https://image.tmdb.org/t/p/w500/8Gxv8gSFCU0XGDykEGv7zR1n2ua.jpg" },
  { title: "존 윅 4", genre: "액션 · 범죄", year: "2023", img: "https://image.tmdb.org/t/p/w500/vZloFAK7NmvMGKE7VkF5UHaz0I.jpg" },
  { title: "듄: 파트 2", genre: "SF · 액션", year: "2024", img: "https://image.tmdb.org/t/p/w500/1pdfLvkbY9ohJlCjQH2CZjjYVvJ.jpg" },
  { title: "미션 임파서블", genre: "액션 · 스릴러", year: "2023", img: "https://image.tmdb.org/t/p/w500/NNxYkU70HPurnNCSiCjYAmacwm.jpg" },
  { title: "스파이더맨", genre: "액션 · SF", year: "2021", img: "https://image.tmdb.org/t/p/w500/1g0dhYtq4irTY1GPXvft6k4YLjm.jpg" },
  { title: "인터스텔라", genre: "SF · 드라마", year: "2014", img: "https://image.tmdb.org/t/p/w500/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg" },
  { title: "탑건: 매버릭", genre: "액션 · 드라마", year: "2022", img: "https://image.tmdb.org/t/p/w500/jeGvNOVMs5QIU1VaoGvndYpZ5B.jpg" },
  { title: "매드맥스: 분노의 도로", genre: "액션 · SF", year: "2015", img: "https://image.tmdb.org/t/p/w500/hA2ple9q4qnwxp3hKVNhroipsir.jpg" },
  { title: "다크 나이트", genre: "액션 · 범죄", year: "2008", img: "https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7haRef0WH.jpg" },
  { title: "아바타: 물의 길", genre: "SF · 모험", year: "2022", img: "https://image.tmdb.org/t/p/w500/t6HIqrRAclMCA60NsSmeqe9RmNV.jpg" },
  { title: "베놈", genre: "액션 · SF", year: "2018", img: "https://image.tmdb.org/t/p/w500/2uNW4WbgBXL25BAbXGLnLqX5G1p.jpg" },
  { title: "에브리씽 에브리웨어", genre: "액션 · 코미디", year: "2022", img: "https://image.tmdb.org/t/p/w500/w3LxiVYdWWRvEVdn5RYq6jIqkb1.jpg" }
];

const state = {
  wishlist: JSON.parse(localStorage.getItem("netflix-wishlist") || "[]")
};

function renderRow(row, items) {
  row.innerHTML = items.map((movie, index) => {
    const wished = state.wishlist.includes(movie.title);
    return `
      <article class="movie-card" data-title="${movie.title}" data-index="${index}">
        <img src="${movie.img}" alt="${movie.title}" loading="lazy"
          onerror="this.style.background='linear-gradient(135deg,#222,#555)'; this.removeAttribute('src');">
        <button class="wish-btn ${wished ? "active" : ""}" aria-label="찜하기" data-wish="${movie.title}">
          ${wished ? "♥" : "+"}
        </button>
        <div class="movie-overlay">
          <p class="movie-title">${movie.title}</p>
          <p class="movie-info">${movie.year} · ${movie.genre}</p>
        </div>
      </article>`;
  }).join("");
}

renderRow(document.querySelector('[data-row="popular"]'), movies.slice(0, 6));
renderRow(document.querySelector('[data-row="action"]'), movies.filter(m => m.genre.includes("액션")).slice(0, 6));
renderRow(document.querySelector('[data-row="series"]'), movies.slice(4, 10));

function renderWishlist() {
  const items = movies.filter(m => state.wishlist.includes(m.title));
  renderRow(document.querySelector('[data-row="my-list"]'), items);
  document.querySelector(".empty-message").classList.toggle("show", items.length === 0);
}
renderWishlist();

document.addEventListener("click", (e) => {
  const wish = e.target.closest("[data-wish]");
  if (wish) {
    e.stopPropagation();
    const title = wish.dataset.wish;
    if (state.wishlist.includes(title)) {
      state.wishlist = state.wishlist.filter(x => x !== title);
    } else {
      state.wishlist.push(title);
    }
    localStorage.setItem("netflix-wishlist", JSON.stringify(state.wishlist));
    document.querySelectorAll("[data-row]").forEach((row) => {
      if (row.dataset.row === "my-list") return;
      const item = row.querySelector(`[data-wish="${CSS.escape(title)}"]`);
      if (item) {
        const active = state.wishlist.includes(title);
        item.classList.toggle("active", active);
        item.textContent = active ? "♥" : "+";
      }
    });
    renderWishlist();
    return;
  }

  const card = e.target.closest(".movie-card");
  if (card) {
    const movie = movies.find(m => m.title === card.dataset.title);
    if (movie) openModal(movie);
  }

  if (e.target.matches('[data-action="play"]')) {
    alert("재생 버튼을 클릭했습니다. 실제 서비스에서는 영상 재생 페이지로 연결하면 됩니다.");
  }
  if (e.target.matches('[data-action="info"]')) {
    openModal(movies[0]);
  }
});

const modal = document.getElementById("infoModal");
function openModal(movie) {
  document.getElementById("modalTitle").textContent = movie.title;
  document.getElementById("modalText").textContent = `${movie.year} · ${movie.genre} — 지금 바로 감상할 수 있는 인기 콘텐츠입니다.`;
  document.querySelector(".modal-poster").style.backgroundImage =
    `linear-gradient(0deg,#181818,transparent), url("${movie.img}")`;
  modal.classList.add("open");
  modal.setAttribute("aria-hidden", "false");
}
function closeModal() {
  modal.classList.remove("open");
  modal.setAttribute("aria-hidden", "true");
}
document.querySelector(".modal-close").addEventListener("click", closeModal);
modal.addEventListener("click", e => { if (e.target === modal) closeModal(); });

const searchPanel = document.querySelector(".search-panel");
const searchInput = document.getElementById("searchInput");
const searchResults = document.getElementById("searchResults");

document.querySelector(".search-btn").addEventListener("click", () => {
  searchPanel.classList.add("open");
  searchPanel.setAttribute("aria-hidden", "false");
  setTimeout(() => searchInput.focus(), 100);
});
document.querySelector(".close-search").addEventListener("click", closeSearch);
function closeSearch() {
  searchPanel.classList.remove("open");
  searchPanel.setAttribute("aria-hidden", "true");
  searchInput.value = "";
  searchResults.innerHTML = "";
}
searchInput.addEventListener("input", () => {
  const keyword = searchInput.value.trim().toLowerCase();
  const results = movies.filter(m =>
    `${m.title} ${m.genre}`.toLowerCase().includes(keyword)
  );
  searchResults.innerHTML = keyword
    ? results.map(m => `
      <article class="movie-card" data-title="${m.title}">
        <img src="${m.img}" alt="${m.title}" loading="lazy">
        <div class="movie-overlay" style="opacity:1">
          <p class="movie-title">${m.title}</p>
          <p class="movie-info">${m.year} · ${m.genre}</p>
        </div>
      </article>`).join("")
    : "";
});

document.querySelector(".sound-btn").addEventListener("click", (e) => {
  e.currentTarget.textContent = e.currentTarget.textContent === "🔇" ? "🔊" : "🔇";
});

const header = document.querySelector(".header");
window.addEventListener("scroll", () => {
  header.classList.toggle("scrolled", window.scrollY > 30);
});

document.addEventListener("keydown", e => {
  if (e.key === "Escape") {
    closeModal();
    closeSearch();
  }
});
