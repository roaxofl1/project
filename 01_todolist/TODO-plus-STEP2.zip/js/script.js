/* ========================================
   TODO+ STEP 2
   CRUD + Calendar + Search + Filter + Sort
======================================== */

const STORAGE_KEY = "todoPlus.todos";

const state = {
  todos: loadTodos(),
  selectedDate: formatDate(new Date()),
  calendarDate: new Date(),
  filter: "all",
  search: "",
  sort: "date",
  editingId: null
};

const els = {
  headerDate: document.getElementById("headerDate"),
  heroDate: document.getElementById("heroDate"),
  progressText: document.getElementById("progressText"),
  progressCount: document.getElementById("progressCount"),
  progressBar: document.getElementById("progressBar"),
  calendarTitle: document.getElementById("calendarTitle"),
  calendarGrid: document.getElementById("calendarGrid"),
  selectedDateText: document.getElementById("selectedDateText"),
  listTitle: document.getElementById("listTitle"),
  listCount: document.getElementById("listCount"),
  searchInput: document.getElementById("searchInput"),
  sortSelect: document.getElementById("sortSelect"),
  todoList: document.getElementById("todoList"),
  emptyState: document.getElementById("emptyState"),
  emptyTitle: document.getElementById("emptyTitle"),
  emptyDesc: document.getElementById("emptyDesc"),
  openAddModal: document.getElementById("openAddModal"),
  emptyAddBtn: document.getElementById("emptyAddBtn"),
  todoModal: document.getElementById("todoModal"),
  modalTitle: document.getElementById("modalTitle"),
  closeModal: document.getElementById("closeModal"),
  cancelModal: document.getElementById("cancelModal"),
  todoForm: document.getElementById("todoForm"),
  titleInput: document.getElementById("title"),
  descriptionInput: document.getElementById("description"),
  dateInput: document.getElementById("date"),
  timeInput: document.getElementById("time"),
  categoryInput: document.getElementById("category"),
  priorityInput: document.getElementById("priority"),
  prevMonth: document.getElementById("prevMonth"),
  nextMonth: document.getElementById("nextMonth"),
  goToday: document.getElementById("goToday")
};

init();

function init() {
  bindEvents();
  updateHeaderDates();
  renderCalendar();
  renderAll();
}

function bindEvents() {
  els.openAddModal.addEventListener("click", () => openModal());
  els.emptyAddBtn.addEventListener("click", () => openModal());
  els.closeModal.addEventListener("click", closeModal);
  els.cancelModal.addEventListener("click", closeModal);
  els.todoModal.addEventListener("click", (event) => {
    if (event.target === els.todoModal) closeModal();
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && !els.todoModal.hidden) closeModal();
  });

  els.todoForm.addEventListener("submit", handleFormSubmit);

  els.searchInput.addEventListener("input", (event) => {
    state.search = event.target.value.trim().toLowerCase();
    renderTodoList();
  });

  document.querySelectorAll(".filter-btn").forEach((button) => {
    button.addEventListener("click", () => {
      state.filter = button.dataset.filter;
      document.querySelectorAll(".filter-btn").forEach((btn) => btn.classList.remove("active"));
      button.classList.add("active");
      renderTodoList();
    });
  });

  els.sortSelect.addEventListener("change", (event) => {
    state.sort = event.target.value;
    renderTodoList();
  });

  els.prevMonth.addEventListener("click", () => {
    state.calendarDate = new Date(state.calendarDate.getFullYear(), state.calendarDate.getMonth() - 1, 1);
    renderCalendar();
  });

  els.nextMonth.addEventListener("click", () => {
    state.calendarDate = new Date(state.calendarDate.getFullYear(), state.calendarDate.getMonth() + 1, 1);
    renderCalendar();
  });

  els.goToday.addEventListener("click", () => {
    const today = new Date();
    state.calendarDate = new Date(today.getFullYear(), today.getMonth(), 1);
    state.selectedDate = formatDate(today);
    renderCalendar();
    renderTodoList();
  });

  els.todoList.addEventListener("click", handleTodoListClick);
}

function loadTodos() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch (error) {
    console.error("Todo 데이터를 불러오지 못했습니다.", error);
    return [];
  }
}

function saveTodos() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state.todos));
}

function formatDate(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function parseDate(dateString) {
  const [year, month, day] = dateString.split("-").map(Number);
  return new Date(year, month - 1, day);
}

function formatKoreanDate(dateString) {
  const date = parseDate(dateString);
  const weekdays = ["일", "월", "화", "수", "목", "금", "토"];
  return `${date.getFullYear()}년 ${date.getMonth() + 1}월 ${date.getDate()}일 ${weekdays[date.getDay()]}요일`;
}

function formatShortDate(dateString) {
  const date = parseDate(dateString);
  return `${date.getMonth() + 1}/${date.getDate()}`;
}

function updateHeaderDates() {
  const today = new Date();
  els.headerDate.textContent = `${today.getFullYear()}.${String(today.getMonth() + 1).padStart(2, "0")}.${String(today.getDate()).padStart(2, "0")}`;
  els.heroDate.textContent = formatKoreanDate(formatDate(today));
}

function renderAll() {
  renderProgress();
  renderCalendar();
  renderTodoList();
}

function renderProgress() {
  const today = formatDate(new Date());
  const todayTodos = state.todos.filter((todo) => todo.date === today);
  const completed = todayTodos.filter((todo) => todo.completed).length;
  const total = todayTodos.length;
  const percent = total ? Math.round((completed / total) * 100) : 0;

  els.progressText.textContent = `${percent}%`;
  els.progressCount.textContent = `${completed} / ${total} 완료`;
  els.progressBar.style.width = `${percent}%`;
}

function renderCalendar() {
  const year = state.calendarDate.getFullYear();
  const month = state.calendarDate.getMonth();

  els.calendarTitle.textContent = `${year}년 ${month + 1}월`;

  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const prevMonthDays = new Date(year, month, 0).getDate();

  els.calendarGrid.innerHTML = "";

  const totalCells = Math.ceil((firstDay + daysInMonth) / 7) * 7;

  for (let index = 0; index < totalCells; index += 1) {
    let dayNumber;
    let cellDate;
    let otherMonth = false;

    if (index < firstDay) {
      dayNumber = prevMonthDays - firstDay + index + 1;
      cellDate = new Date(year, month - 1, dayNumber);
      otherMonth = true;
    } else if (index >= firstDay + daysInMonth) {
      dayNumber = index - (firstDay + daysInMonth) + 1;
      cellDate = new Date(year, month + 1, dayNumber);
      otherMonth = true;
    } else {
      dayNumber = index - firstDay + 1;
      cellDate = new Date(year, month, dayNumber);
    }

    const dateKey = formatDate(cellDate);
    const button = document.createElement("button");
    button.type = "button";
    button.className = "calendar-day";
    if (otherMonth) button.classList.add("other-month");
    if (dateKey === formatDate(new Date())) button.classList.add("today");
    if (dateKey === state.selectedDate) button.classList.add("selected");

    const hasTodo = state.todos.some((todo) => todo.date === dateKey);
    const hasHigh = state.todos.some((todo) => todo.date === dateKey && todo.priority === "high");

    button.innerHTML = `
      <div class="calendar-day-number">${dayNumber}</div>
      ${hasTodo ? `<div class="calendar-dot ${hasHigh ? "high" : ""}"></div>` : ""}
    `;

    button.addEventListener("click", () => {
      state.selectedDate = dateKey;
      state.calendarDate = new Date(cellDate.getFullYear(), cellDate.getMonth(), 1);
      state.filter = "all";
      document.querySelectorAll(".filter-btn").forEach((btn) => btn.classList.toggle("active", btn.dataset.filter === "all"));
      renderCalendar();
      renderTodoList();
    });

    els.calendarGrid.appendChild(button);
  }
}

function getVisibleTodos() {
  let result = [...state.todos];

  if (state.selectedDate) {
    result = result.filter((todo) => todo.date === state.selectedDate);
  }

  if (state.filter === "today") {
    const today = formatDate(new Date());
    result = result.filter((todo) => todo.date === today);
  } else if (state.filter === "pending") {
    result = result.filter((todo) => !todo.completed);
  } else if (state.filter === "completed") {
    result = result.filter((todo) => todo.completed);
  } else if (state.filter === "high") {
    result = result.filter((todo) => todo.priority === "high");
  }

  if (state.search) {
    result = result.filter((todo) =>
      [todo.title, todo.description, todo.category]
        .filter(Boolean)
        .some((text) => String(text).toLowerCase().includes(state.search))
    );
  }

  const priorityWeight = { high: 0, medium: 1, low: 2 };

  result.sort((a, b) => {
    if (state.sort === "priority") {
      return (priorityWeight[a.priority] ?? 9) - (priorityWeight[b.priority] ?? 9)
        || String(a.time || "99:99").localeCompare(String(b.time || "99:99"));
    }
    if (state.sort === "created") {
      return String(b.createdAt || "").localeCompare(String(a.createdAt || ""));
    }

    return String(a.date).localeCompare(String(b.date))
      || String(a.time || "99:99").localeCompare(String(b.time || "99:99"))
      || Number(a.completed) - Number(b.completed);
  });

  return result;
}

function renderTodoList() {
  const visible = getVisibleTodos();

  els.selectedDateText.textContent = state.selectedDate ? formatKoreanDate(state.selectedDate) : "";
  els.listTitle.textContent = state.selectedDate ? `${formatShortDate(state.selectedDate)} 할 일` : "오늘의 할 일";
  els.listCount.textContent = `${visible.length}개`;

  els.todoList.innerHTML = "";

  if (!visible.length) {
    showEmptyState();
    return;
  }

  els.emptyState.hidden = true;

  visible.forEach((todo) => {
    const item = document.createElement("article");
    item.className = `todo-item ${todo.completed ? "completed" : ""}`;

    const priorityLabel = { high: "높음", medium: "보통", low: "낮음" }[todo.priority] || "보통";
    const timeText = todo.time ? `🕒 ${todo.time}` : "🕒 시간 미정";

    item.innerHTML = `
      <button class="todo-check ${todo.completed ? "checked" : ""}" type="button"
        data-action="toggle" data-id="${escapeAttr(todo.id)}"
        aria-label="${todo.completed ? "완료 취소" : "완료 처리"}"></button>

      <div>
        <h3 class="todo-title">${escapeHtml(todo.title)}</h3>
        <div class="todo-meta">
          <span class="meta-chip">${timeText}</span>
          <span class="meta-chip">${escapeHtml(todo.category || "기타")}</span>
          <span class="meta-chip">
            <span class="priority-dot ${escapeAttr(todo.priority || "medium")}"></span>
            ${priorityLabel}
          </span>
        </div>
      </div>

      <div class="todo-actions">
        <button class="text-btn" type="button" data-action="edit" data-id="${escapeAttr(todo.id)}">수정</button>
        <button class="text-btn delete" type="button" data-action="delete" data-id="${escapeAttr(todo.id)}">삭제</button>
      </div>
    `;

    els.todoList.appendChild(item);
  });
}

function showEmptyState() {
  els.emptyState.hidden = false;

  if (state.search) {
    els.emptyTitle.textContent = "검색 결과가 없습니다.";
    els.emptyDesc.textContent = "다른 검색어를 입력해 보세요.";
  } else if (state.selectedDate) {
    els.emptyTitle.textContent = "이 날짜에는 예정된 일이 없습니다.";
    els.emptyDesc.textContent = "새로운 할 일을 추가해 보세요.";
  } else {
    els.emptyTitle.textContent = "등록된 할 일이 없습니다.";
    els.emptyDesc.textContent = "새로운 할 일을 추가해 보세요.";
  }
}

function openModal(todo = null) {
  state.editingId = todo ? todo.id : null;
  els.modalTitle.textContent = todo ? "할 일 수정" : "할 일 추가";
  els.todoForm.reset();

  els.dateInput.value = todo?.date || state.selectedDate || formatDate(new Date());
  els.timeInput.value = todo?.time || "";
  els.categoryInput.value = todo?.category || "업무";
  els.priorityInput.value = todo?.priority || "medium";
  els.titleInput.value = todo?.title || "";
  els.descriptionInput.value = todo?.description || "";

  els.todoModal.hidden = false;
  document.body.style.overflow = "hidden";
  setTimeout(() => els.titleInput.focus(), 0);
}

function closeModal() {
  els.todoModal.hidden = true;
  document.body.style.overflow = "";
  state.editingId = null;
}

function handleFormSubmit(event) {
  event.preventDefault();

  const formData = new FormData(els.todoForm);
  const now = new Date().toISOString();

  const payload = {
    title: String(formData.get("title") || "").trim(),
    description: String(formData.get("description") || "").trim(),
    date: String(formData.get("date") || ""),
    time: String(formData.get("time") || ""),
    category: String(formData.get("category") || "업무"),
    priority: String(formData.get("priority") || "medium")
  };

  if (!payload.title || !payload.date) return;

  if (state.editingId) {
    const index = state.todos.findIndex((todo) => String(todo.id) === String(state.editingId));
    if (index !== -1) {
      state.todos[index] = {
        ...state.todos[index],
        ...payload,
        updatedAt: now
      };
    }
  } else {
    state.todos.push({
      id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()),
      ...payload,
      completed: false,
      createdAt: now,
      updatedAt: now
    });
  }

  saveTodos();
  state.selectedDate = payload.date;
  state.calendarDate = parseDate(payload.date);
  closeModal();
  renderAll();
}

function handleTodoListClick(event) {
  const button = event.target.closest("[data-action]");
  if (!button) return;

  const id = button.dataset.id;
  const action = button.dataset.action;
  const todo = state.todos.find((item) => String(item.id) === String(id));

  if (!todo) return;

  if (action === "toggle") {
    todo.completed = !todo.completed;
    todo.completedAt = todo.completed ? new Date().toISOString() : null;
    todo.updatedAt = new Date().toISOString();
    saveTodos();
    renderAll();
    return;
  }

  if (action === "edit") {
    openModal(todo);
    return;
  }

  if (action === "delete") {
    const shouldDelete = window.confirm(`"${todo.title}" 할 일을 삭제할까요?`);
    if (!shouldDelete) return;
    state.todos = state.todos.filter((item) => String(item.id) !== String(id));
    saveTodos();
    renderAll();
  }
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function escapeAttr(value) {
  return escapeHtml(value).replaceAll("`", "&#096;");
}

// 외부에서 STEP1 코드를 가져왔을 때도 자동으로 기본 데이터 형식을 보정한다.
state.todos = state.todos.map((todo) => ({
  ...todo,
  category: todo.category || "업무",
  priority: todo.priority || "medium",
  completed: Boolean(todo.completed)
}));
saveTodos();
