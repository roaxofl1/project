/* =========================================================
   STREAMFLIX SCRIPT
========================================================= */

const API_KEY = "";
const TMDB_BASE = "https://api.themoviedb.org/3";
const IMAGE_BASE = "https://image.tmdb.org/t/p/w500";
const BACKDROP_BASE = "https://image.tmdb.org/t/p/original";

const rows = {
    popular: document.querySelector('[data-row="popular"]'),
    action: document.querySelector('[data-row="action"]'),
    comedy: document.querySelector('[data-row="comedy"]'),
    horror: document.querySelector('[data-row="horror"]'),
    romance: document.querySelector('[data-row="romance"]'),
    documentary: document.querySelector('[data-row="documentary"]'),
    "top-rated": document.querySelector('[data-row="top-rated"]'),
    "my-list": document.querySelector('[data-row="my-list"]')
};

const heroBackdrop = document.getElementById("heroBackdrop");
const heroVideo = document.getElementById("heroVideo");
const heroTitle = document.getElementById("heroTitle");
const heroMeta = document.getElementById("heroMeta");
const heroDescription = document.getElementById("heroDescription");

const searchPanel = document.getElementById("searchPanel");
const searchInput = document.getElementById("searchInput");
const searchResults = document.getElementById("searchResults");

const infoModal = document.getElementById("infoModal");
const modalPoster = document.getElementById("modalPoster");
const modalTitle = document.getElementById("modalTitle");
const modalMeta = document.getElementById("modalMeta");
const modalText = document.getElementById("modalText");
const modalWishBtn = document.getElementById("modalWishBtn");

const loginModal = document.getElementById("loginModal");
const loginBtn = document.getElementById("loginBtn");

let heroMovie = null;
let modalMovie = null;
let searchTimer = null;
let currentHeroVideoId = null;


/* =========================================================
   TMDB
========================================================= */

async function tmdb(path, params = {}) {

    if (!API_KEY) {
        console.warn("TMDB API KEY를 입력해주세요.");
        return null;
    }

    const url = new URL(TMDB_BASE + path);

    url.searchParams.set("api_key", API_KEY);
    url.searchParams.set("language", "ko-KR");
    url.searchParams.set("region", "KR");

    Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== "") {
            url.searchParams.set(key, value);
        }
    });

    try {

        const response = await fetch(url);

        if (!response.ok) {
            throw new Error(`TMDB HTTP ${response.status}`);
        }

        return await response.json();

    } catch (error) {

        console.error("TMDB 요청 오류:", error);
        return null;
    }
}


/* =========================================================
   MOVIE DATA
========================================================= */

async function loadMovies() {

    const configs = [
        ["popular", "/movie/popular", { page: 1 }],
        ["action", "/discover/movie", { with_genres: 28, sort_by: "popularity.desc", page: 1 }],
        ["comedy", "/discover/movie", { with_genres: 35, sort_by: "popularity.desc", page: 1 }],
        ["horror", "/discover/movie", { with_genres: 27, sort_by: "popularity.desc", page: 1 }],
        ["romance", "/discover/movie", { with_genres: 10749, sort_by: "popularity.desc", page: 1 }],
        ["documentary", "/discover/movie", { with_genres: 99, sort_by: "popularity.desc", page: 1 }],
        ["top-rated", "/movie/top_rated", { page: 1 }]
    ];

    await Promise.all(
        configs.map(async ([name, path, params]) => {

            const data = await tmdb(path, params);

            if (!data || !data.results) {
                renderError(rows[name]);
                return;
            }

            renderMovies(rows[name], data.results.slice(0, 20));
        })
    );

    renderWishlist();
    updateAllSliderButtons();
}


/* =========================================================
   MOVIE CARD
========================================================= */

function renderMovies(container, movies) {

    if (!container) return;

    container.innerHTML = "";

    const validMovies = movies.filter(movie => movie.poster_path);

    if (!validMovies.length) {
        container.innerHTML = `
            <div class="movie-loading">
                표시할 영화가 없습니다.
            </div>
        `;
        return;
    }

    validMovies.forEach(movie => {
        container.appendChild(createMovieCard(movie));
    });
}


function createMovieCard(movie) {

    const card = document.createElement("article");
    card.className = "movie-card";

    const isWished = getWishlist().some(item => item.id === movie.id);

    const year = movie.release_date
        ? movie.release_date.substring(0, 4)
        : "미정";

    const rating = Number(movie.vote_average || 0).toFixed(1);

    card.innerHTML = `
        <img
            src="${IMAGE_BASE}${movie.poster_path}"
            alt="${escapeHTML(movie.title || "영화")}"
            loading="lazy"
        >

        <button
            class="wish-btn ${isWished ? "active" : ""}"
            type="button"
            aria-label="찜하기"
        >
            ${isWished ? "♥" : "+"}
        </button>

        <div class="movie-overlay">

            <span class="movie-title">
                ${escapeHTML(movie.title || "제목 없음")}
            </span>

            <span class="movie-info">
                ${year} · ⭐ ${rating}
            </span>

        </div>

        <div class="movie-overview">
            ${escapeHTML(movie.overview || "등록된 줄거리 정보가 없습니다.")}
        </div>
    `;

    const wishBtn = card.querySelector(".wish-btn");

    wishBtn.addEventListener("click", event => {
        event.stopPropagation();
        toggleWishlist(movie);
    });

    card.addEventListener("click", () => {
        openInfoModal(movie);
    });

    return card;
}


/* =========================================================
   WISHLIST
========================================================= */

function getWishlist() {

    try {
        return JSON.parse(localStorage.getItem("streamflixWishlist")) || [];
    } catch {
        return [];
    }
}


function saveWishlist(list) {
    localStorage.setItem(
        "streamflixWishlist",
        JSON.stringify(list)
    );
}


function toggleWishlist(movie) {

    let list = getWishlist();

    const exists = list.some(item => item.id === movie.id);

    if (exists) {
        list = list.filter(item => item.id !== movie.id);
    } else {
        list.push(movie);
    }

    saveWishlist(list);

    refreshWishButtons(movie.id);
    renderWishlist();

    if (modalMovie && modalMovie.id === movie.id) {
        updateModalWishButton();
    }
}


function refreshWishButtons(movieId) {

    const wished = getWishlist()
        .some(movie => movie.id === movieId);

    document
        .querySelectorAll(".movie-card")
        .forEach(card => {

            const img = card.querySelector("img");
            const button = card.querySelector(".wish-btn");

            if (!img || !button) return;

            if (img.src.includes(`/w500/${movieId}`)) {
                button.classList.toggle("active", wished);
                button.textContent = wished ? "♥" : "+";
            }
        });
}


function renderWishlist() {

    const container = rows["my-list"];
    const emptyMessage = document.querySelector(".empty-message");

    if (!container) return;

    const list = getWishlist();

    container.innerHTML = "";

    if (!list.length) {

        if (emptyMessage) {
            emptyMessage.classList.add("show");
        }

        updateSliderButtons(container);
        return;
    }

    if (emptyMessage) {
        emptyMessage.classList.remove("show");
    }

    list.forEach(movie => {
        container.appendChild(createMovieCard(movie));
    });

    updateSliderButtons(container);
}


/* =========================================================
   HERO
========================================================= */

async function loadRandomHero() {

    const data = await tmdb("/movie/popular", {
        page: Math.floor(Math.random() * 3) + 1
    });

    if (!data || !data.results || !data.results.length) {
        return;
    }

    const movies = data.results.filter(
        movie => movie.backdrop_path && movie.title
    );

    if (!movies.length) return;

    heroMovie = movies[
        Math.floor(Math.random() * movies.length)
    ];

    renderHero(heroMovie);

    loadHeroTrailer(heroMovie.id);
}


function renderHero(movie) {

    heroBackdrop.style.backgroundImage =
        `url("${BACKDROP_BASE}${movie.backdrop_path}")`;

    heroTitle.textContent = movie.title || "제목 없음";

    const year = movie.release_date
        ? movie.release_date.substring(0, 4)
        : "미정";

    const rating = Number(movie.vote_average || 0).toFixed(1);

    heroMeta.innerHTML = `
        <span>${year}</span>
        <span>12+</span>
        <span class="hero-rating">★ ${rating}</span>
        <span>영화</span>
    `;

    heroDescription.textContent =
        movie.overview ||
        "새로운 영화 이야기가 시작됩니다.";
}


async function loadHeroTrailer(movieId) {

    const data = await tmdb(`/movie/${movieId}/videos`, {
        language: "ko-KR"
    });

    let videos = data?.results || [];

    let trailer =
        videos.find(video =>
            video.site === "YouTube" &&
            video.type === "Trailer" &&
            video.official
        );

    if (!trailer) {
        trailer =
            videos.find(video =>
                video.site === "YouTube" &&
                video.type === "Trailer"
            );
    }

    if (!trailer) {
        const enData = await tmdb(`/movie/${movieId}/videos`, {
            language: "en-US"
        });

        videos = enData?.results || [];

        trailer =
            videos.find(video =>
                video.site === "YouTube" &&
                video.type === "Trailer" &&
                video.official
            ) ||
            videos.find(video =>
                video.site === "YouTube" &&
                video.type === "Trailer"
            );
    }

    if (!trailer) return;

    currentHeroVideoId = trailer.key;

    heroVideo.innerHTML = `
        <iframe
            id="heroYoutube"
            src="https://www.youtube.com/embed/${trailer.key}?autoplay=1&mute=1&controls=0&loop=1&playlist=${trailer.key}&playsinline=1&rel=0&modestbranding=1"
            title="영화 미리보기"
            allow="autoplay; encrypted-media"
            referrerpolicy="strict-origin-when-cross-origin"
        ></iframe>
    `;

    heroVideo.classList.add("active");
}


/* =========================================================
   HERO BUTTON
========================================================= */

document.getElementById("heroPlayBtn").addEventListener("click", () => {

    if (!heroMovie) return;

    openInfoModal(heroMovie);
});


document.getElementById("heroInfoBtn").addEventListener("click", () => {

    if (!heroMovie) return;

    openInfoModal(heroMovie);
});


/* =========================================================
   SOUND
========================================================= */

let videoMuted = true;

document.getElementById("soundBtn").addEventListener("click", () => {

    const iframe = document.getElementById("heroYoutube");

    if (!iframe) return;

    videoMuted = !videoMuted;

    iframe.contentWindow.postMessage(
        JSON.stringify({
            event: "command",
            func: videoMuted ? "mute" : "unMute"
        }),
        "*"
    );

    document.getElementById("soundBtn").textContent =
        videoMuted ? "🔇" : "🔊";
});


/* =========================================================
   INFO MODAL
========================================================= */

function openInfoModal(movie) {

    modalMovie = movie;

    modalPoster.style.backgroundImage =
        movie.poster_path
            ? `url("${IMAGE_BASE}${movie.poster_path}")`
            : "none";

    modalTitle.textContent =
        movie.title || "제목 없음";

    const year = movie.release_date
        ? movie.release_date.substring(0, 4)
        : "미정";

    const rating =
        Number(movie.vote_average || 0).toFixed(1);

    modalMeta.textContent =
        `${year} · ⭐ ${rating} · 영화`;

    modalText.textContent =
        movie.overview ||
        "등록된 줄거리 정보가 없습니다.";

    updateModalWishButton();

    infoModal.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
}


function closeInfoModal() {

    infoModal.setAttribute("aria-hidden", "true");
    document.body.classList.remove("modal-open");
    modalMovie = null;
}


function updateModalWishButton() {

    if (!modalMovie) return;

    const wished = getWishlist()
        .some(movie => movie.id === modalMovie.id);

    modalWishBtn.textContent =
        wished ? "♥ 찜 취소" : "＋ 내가 찜하기";
}


document.getElementById("modalClose")
    .addEventListener("click", closeInfoModal);

infoModal.addEventListener("click", event => {

    if (event.target === infoModal) {
        closeInfoModal();
    }
});


modalWishBtn.addEventListener("click", () => {

    if (!modalMovie) return;

    toggleWishlist(modalMovie);
});


/* =========================================================
   SEARCH
========================================================= */

function openSearch() {

    searchPanel.setAttribute("aria-hidden", "false");

    setTimeout(() => {
        searchInput.focus();
    }, 100);

    document.body.classList.add("modal-open");
}


function closeSearch() {

    searchPanel.setAttribute("aria-hidden", "true");
    searchInput.value = "";
    searchResults.innerHTML = "";

    document.body.classList.remove("modal-open");
}


document.getElementById("searchBtn")
    .addEventListener("click", openSearch);

document.getElementById("closeSearch")
    .addEventListener("click", closeSearch);

searchInput.addEventListener("input", () => {

    clearTimeout(searchTimer);

    const keyword = searchInput.value.trim();

    if (!keyword) {
        searchResults.innerHTML = "";
        return;
    }

    searchTimer = setTimeout(
        () => searchMovies(keyword),
        400
    );
});


async function searchMovies(keyword) {

    searchResults.innerHTML = `
        <div class="movie-loading">
            검색 중...
        </div>
    `;

    const data = await tmdb("/search/movie", {
        query: keyword,
        page: 1,
        include_adult: false
    });

    if (!data || !data.results) {

        searchResults.innerHTML = `
            <div class="movie-loading">
                검색 결과를 불러오지 못했습니다.
            </div>
        `;

        return;
    }

    const movies = data.results
        .filter(movie => movie.poster_path)
        .slice(0, 20);

    searchResults.innerHTML = "";

    if (!movies.length) {

        searchResults.innerHTML = `
            <div class="movie-loading">
                검색 결과가 없습니다.
            </div>
        `;

        return;
    }

    movies.forEach(movie => {
        searchResults.appendChild(createMovieCard(movie));
    });
}


/* =========================================================
   SLIDER
   한 번 클릭할 때 영화 1개씩 이동
========================================================= */

document
    .querySelectorAll(".movie-slider")
    .forEach(slider => {

        const row = slider.querySelector(".movie-row");
        const prev = slider.querySelector(".slider-prev");
        const next = slider.querySelector(".slider-next");

        prev.addEventListener("click", () => {

            const card = row.querySelector(".movie-card");

            if (!card) return;

            row.scrollBy({
                left: -(card.offsetWidth + 10),
                behavior: "smooth"
            });
        });

        next.addEventListener("click", () => {

            const card = row.querySelector(".movie-card");

            if (!card) return;

            row.scrollBy({
                left: card.offsetWidth + 10,
                behavior: "smooth"
            });
        });

        row.addEventListener("scroll", () => {
            updateSliderButtons(row);
        });

        enableDrag(row);
    });


function updateSliderButtons(row) {

    const slider = row.closest(".movie-slider");

    if (!slider) return;

    const prev = slider.querySelector(".slider-prev");
    const next = slider.querySelector(".slider-next");

    if (!prev || !next) return;

    const maxScroll =
        row.scrollWidth - row.clientWidth;

    prev.classList.toggle(
        "disabled",
        row.scrollLeft <= 5
    );

    next.classList.toggle(
        "disabled",
        row.scrollLeft >= maxScroll - 5
    );
}


function updateAllSliderButtons() {

    document
        .querySelectorAll(".movie-row")
        .forEach(updateSliderButtons);
}


/* =========================================================
   MOUSE DRAG / TOUCH
========================================================= */

function enableDrag(row) {

    let isDown = false;
    let startX = 0;
    let startScroll = 0;

    row.addEventListener("mousedown", event => {

        if (event.target.closest(".wish-btn")) return;

        isDown = true;

        row.classList.add("dragging");

        startX = event.pageX;
        startScroll = row.scrollLeft;
    });

    window.addEventListener("mouseup", () => {

        isDown = false;
        row.classList.remove("dragging");
    });

    row.addEventListener("mousemove", event => {

        if (!isDown) return;

        event.preventDefault();

        const distance =
            (event.pageX - startX) * 1.2;

        row.scrollLeft =
            startScroll - distance;
    });
}


/* =========================================================
   LOGIN
========================================================= */

function openLogin() {

    loginModal.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
}


function closeLogin() {

    loginModal.setAttribute("aria-hidden", "true");
    document.body.classList.remove("modal-open");
}


loginBtn.addEventListener("click", () => {

    const loggedIn =
        localStorage.getItem("streamflixLoggedIn") === "true";

    if (loggedIn) {

        localStorage.removeItem("streamflixLoggedIn");

        loginBtn.textContent = "로그인";

        alert("로그아웃되었습니다.");

        return;
    }

    openLogin();
});


document.getElementById("loginClose")
    .addEventListener("click", closeLogin);


document.querySelector(".login-modal-bg")
    .addEventListener("click", closeLogin);


document.getElementById("loginForm")
    .addEventListener("submit", event => {

        event.preventDefault();

        const email =
            document.getElementById("loginEmail").value.trim();

        const password =
            document.getElementById("loginPassword").value;

        if (!email || !password) return;

        localStorage.setItem(
            "streamflixLoggedIn",
            "true"
        );

        loginBtn.textContent = "로그아웃";

        closeLogin();

        alert("로그인되었습니다.");
    });


function restoreLogin() {

    const loggedIn =
        localStorage.getItem("streamflixLoggedIn") === "true";

    loginBtn.textContent =
        loggedIn ? "로그아웃" : "로그인";
}


/* =========================================================
   HEADER SCROLL
========================================================= */

window.addEventListener("scroll", () => {

    const header =
        document.querySelector(".header");

    header.classList.toggle(
        "scrolled",
        window.scrollY > 30
    );
});


/* =========================================================
   ESC
========================================================= */

document.addEventListener("keydown", event => {

    if (event.key !== "Escape") return;

    if (searchPanel.getAttribute("aria-hidden") === "false") {
        closeSearch();
    }

    if (infoModal.getAttribute("aria-hidden") === "false") {
        closeInfoModal();
    }

    if (loginModal.getAttribute("aria-hidden") === "false") {
        closeLogin();
    }
});


/* =========================================================
   UTIL
========================================================= */

function renderError(container) {

    if (!container) return;

    container.innerHTML = `
        <div class="movie-loading">
            영화를 불러오지 못했습니다.
        </div>
    `;
}


function escapeHTML(value) {

    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}


/* =========================================================
   START
========================================================= */

async function init() {

    restoreLogin();

    await Promise.all([
        loadMovies(),
        loadRandomHero()
    ]);

    updateAllSliderButtons();
}

init();
